<div class="wrapper">
    <footer class="footer">
        <div class="footer-content">
            <p>&copy; <?php echo date('Y'); ?> Feyenoord</p>
        </div>
    </footer>
</div>